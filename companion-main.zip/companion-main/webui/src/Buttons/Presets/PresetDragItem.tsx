export interface PresetDragItem {
	connectionId: string
	presetId: string
}
