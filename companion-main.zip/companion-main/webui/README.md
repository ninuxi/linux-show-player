# Getting Started with Companion React UI

This package contains the admin web interface of Companion.

## Available Scripts

### `yarn dev`

Runs the app in the development mode.\
Open [http://localhost:5173](http://localhost:5173) to view it in the browser.

It is configured to connect back to a companion instance running on the default port (8000).\
If you need it to use another port, see `yarn start`

### `yarn start`

Runs the app in the development mode.\
Open [http://localhost:5173](http://localhost:5173) to view it in the browser.

### `yarn build`

Builds the app for production to the `build` folder.\
This gets called when doing an electron build and `yarn update`, so should not be needed often
