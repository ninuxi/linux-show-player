export interface EmulatorPageConfig {
	installName: string | undefined
}

export interface EmulatorListItem {
	id: string
	name: string
}
