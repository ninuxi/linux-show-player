- [Companion GitHub to report bugs](https://bfoc.us/fiobkz0yqs)

- [Facebook group to share information and ask questions](https://bfoc.us/qjk0reeqmy)

- [The Slack group for developers](https://bfoc.us/ke7e9dqgaz)

- [Donate to show your support and fund future development](https://bfoc.us/ccfbf8wm2x)
