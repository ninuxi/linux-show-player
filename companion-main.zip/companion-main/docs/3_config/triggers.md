In the Triggers tab, you can add, edit and remove triggers for your Companion Setup.

Triggers can provide an extra hand in making any setup more automated and allow for you to program some simple automation.

To add a new trigger, click the button **Add Trigger** and fill in the information mentioned below.

![Triggers](images/triggers.png?raw=true 'Triggers')
