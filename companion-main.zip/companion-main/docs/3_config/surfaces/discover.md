Companion supports a few different network protocols for attaching remote surfaces.

![Discovery](images/discover.png?raw=true 'Discovery')

Any surfaces discovered on your network via mdns will be listed here. For each, a short wizard is provided to help connect it to Companion.

If you do not want this discovery, you can disable it in the settings.
