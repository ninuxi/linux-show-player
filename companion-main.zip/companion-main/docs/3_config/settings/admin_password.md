_If enabled, Companion will require a password to view any of the configuration pages. This does not make an installation secure, it is only designed to stop casual browsers_

- **Enable Locking**
  Whether to enable the admin password and lockout feature

- **Session Timeout (minutes, 0 for no timeout)**
  How long after being idle should the ui lock itself. If set to 0 then it does not automatically lock

- **Password**
  The password that must be entered to unlock the ui
