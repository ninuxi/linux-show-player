_If enabled, Companion will listen for Ember+ messages, allowing for external devices to control Companion._

- **Ember+ Listener**  
  Check to allow Companion to be controlled over Ember+.

- **Ember+ Listen Port**  
  The port to listens for Ember+ connections on.
