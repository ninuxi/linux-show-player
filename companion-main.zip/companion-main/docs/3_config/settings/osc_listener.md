_If enabled, Companion will listen for OSC messages, allowing for external devices to control Companion._

- **OSC Listener**  
  Check to allow Companion to be controlled over OSC.

- **OSC Listen Port**  
  The port to listens to commands on.
