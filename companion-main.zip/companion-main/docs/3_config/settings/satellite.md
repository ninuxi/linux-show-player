- **Satellite Listen Port**  
  The port to listens for satellite clients on.
