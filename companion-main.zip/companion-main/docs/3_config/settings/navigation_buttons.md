- **Flip counting direction up/down**  
  When unchecked, pressing the **Page Up** button will increase to the next page (from page 2 to page 3). When checked, it will decrease to the previous page (from page 2 to page 1).

- **Show + and - instead of arrows on page buttons**  
  Changes the page buttons from the standard arrows symbols to + and - symbols instead.

- **Show the topbar on each button**  
  Disable this to hid the Yellow bar and the button number at the top of each button.
