The **Installation Name** is used to define the name this installation of Companion will display in the browser titles. This can be useful in networks containing multiple Companion control devices to differentiate between them in different browser tabs.

![Installation Name](../images/install-name.png?raw=true 'Installation Name')
