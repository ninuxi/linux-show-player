_If enabled, Companion will listen for Artnet messages, allowing for external devices to control Companion. An example GrandMA2 fixture file for controlling Companion can be found on the bottom of that tab._

- **Artnet Listener**  
  Check to allow Companion to be controlled over Artnet.

- **Artnet Universe (first is 0)**  
  The Artnet universe Companion will listen on.

- **Artnet Channel**  
  The starting channel on the universe Companion listens to.
