_If enabled, Companion will listen for RossTalk messages, allowing for external devices to control Companion._

- **RossTalk Listener**  
  Check to allow Companion to be controlled over RossTalk.

- **RossTalk Listen Port**  
  The port to listens for RossTalk clients on.
