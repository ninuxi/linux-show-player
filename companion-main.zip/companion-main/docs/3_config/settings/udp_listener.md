_If enabled, Companion will listen for UDP messages, allowing for external devices to control Companion._

- **UDP Listener**  
  Check to allow Companion to be controlled over UDP.

- **UDP Listen Port**  
  The port to listens to commands on.
