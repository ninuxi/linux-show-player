Here you can reset your configuration, or a subset of it.

![Reset](images/reset.png?raw=true 'Reset')
