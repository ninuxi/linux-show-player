Here you can export your configuration, or a subset of it.

![Export](images/export.png?raw=true 'Export')
