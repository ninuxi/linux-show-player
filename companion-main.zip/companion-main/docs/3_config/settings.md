In the Settings tab, you can configure Companion settings.
