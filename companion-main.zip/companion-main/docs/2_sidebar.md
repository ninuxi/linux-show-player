_You can collapse the sidebar by clicking the icon to the left of the version number at the bottom of the sidebar._

The sidebar is the main way to navigate Companion. It provides quick access to surfaces, pages, module settings, tools, and global configuration.
