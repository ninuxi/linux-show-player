Companion can be remote controlled in several ways. Below you'll find how to do it.
