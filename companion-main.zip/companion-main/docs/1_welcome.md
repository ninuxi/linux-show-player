Remember that Companion is **open source and free**.

If you find something wrong here, please let us know on **[Slack](https://bfoc.us/ke7e9dqgaz)**, via a **[bug report](https://bfoc.us/ead30tx91c)**, or — even better — send a pull request on **[GitHub](https://github.com/bitfocus/companion)** if you can fix it yourself.

Bitfocus initially launched the project, but it's now 100% community driven.

If Companion helps your business, consider **[donating](https://bfoc.us/ccfbf8wm2x)**.

Ok, let's get started!
