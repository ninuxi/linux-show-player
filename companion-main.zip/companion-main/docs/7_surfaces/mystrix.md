It is possible to use the 203 Electronic Matrix with Companion (since v3.4.0).

Enable support for it in Companion's settings and rescan for USB devices.

The layout closely matches the device.
