In some environments, it can be useful to connect remote Stream Decks (or other supported surfaces) to a central Companion instance.

[Companion Satellite](https://user.bitfocus.io/product/companion-satellite) provides this functionality by allowing remote devices to appear as surfaces in a central Companion server.

Note: Satellite currently supports a smaller set of surfaces than a local Companion instance. We are actively working to expand compatibility.
