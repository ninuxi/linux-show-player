You can use any variable within an expression, including custom variables.

Do so with the normal syntax. For example:

- $(internal:time_s)
