Number literals can be integer or floating point numbers. For example:

- 1
- 1234
- 1234.5678

You can also write in other encodings, and they will be automatically converted to base 10. For example:

- 0x10 becomes 16
- 0b11 becomes 3
