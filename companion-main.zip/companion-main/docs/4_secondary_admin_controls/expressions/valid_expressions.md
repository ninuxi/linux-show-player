Expressions can contain _number literals_, _custom variables_, _dynamic variables_, _operators_, _functions_, _ternaries_ and _template strings_.
