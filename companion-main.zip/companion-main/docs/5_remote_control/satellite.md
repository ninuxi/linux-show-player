In some environments, it can be useful to connect a remote Streamdeck into Companion.

We have developed [Companion Satellite](https://user.bitfocus.io/product/companion-satellite) for this purpose.

The satellite protocol follows SemVer and is documented on [the wiki](https://github.com/bitfocus/companion/wiki/Satellite-API)
