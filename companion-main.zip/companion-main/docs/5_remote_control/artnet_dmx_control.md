Please take a look at the attached files under settings for more information.
