This is where all the connections, buttons, and actions are configured.
This section is divided into seven tabs.
