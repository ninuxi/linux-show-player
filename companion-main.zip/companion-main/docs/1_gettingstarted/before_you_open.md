Connect the hardware and software you want to control. Make sure they are on the same network.

In the Elgato Stream Deck app, update the firmware to the latest version.

Close the Elgato Stream Deck app before using Companion. While they can run together, Companion generally works best on its own; using both requires additional configuration explained later.
