The main window is divided into three sections. From left to right:

- Sidebar
- Main panel, typically split into two columns

![Admin GUI](images/admingui.png?raw=true 'Admin GUI')
