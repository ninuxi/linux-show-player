/* eslint-disable @typescript-eslint/no-unsafe-function-type */
declare global {
	const __webpack_require__: Function | void
	const __non_webpack_require__: Function | void
}

/** Needed so that tsc sees this file as containing valid exports */
export {}
