export enum TriggerExecutionSource {
	Test = 'test',
	ConditionChange = 'condition-change',
	Other = 'other',
}
